package com.omse.vrremote

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.graphics.Rect
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.view.InputDevice
import android.view.KeyEvent
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import android.view.accessibility.AccessibilityNodeInfo

class VrRemoteAccessibilityService : AccessibilityService() {

    private val handler = Handler(Looper.getMainLooper())
    private var foregroundPkg: String = ""

    // --- stare zoom (tinut apasat) ---
    private var zoomHeldDir = 0      // 1 = zoom in, -1 = zoom out, 0 = nimic
    private var zoomHoldSteps = 0
    private val zoomHoldRunnable = object : Runnable {
        override fun run() {
            if (zoomHeldDir == 0) return
            val r = GimbalBleManager.zoomHoldRatio
            pinch(if (zoomHeldDir > 0) r else 1f / r, 350)
            zoomHoldSteps++
            GimbalBleManager.logKey("   🔍 salt zoom ${if (zoomHeldDir > 0) "+" else "−"} (#$zoomHoldSteps)")
            GimbalBleManager.updateStatus(GimbalBleManager.statusText)
            handler.postDelayed(this, 900)
        }
    }

    override fun onServiceConnected() {
        super.onServiceConnected()
        GimbalBleManager.serviceRunning = true
        GimbalBleManager.updateStatus(GimbalBleManager.statusText)
    }

    override fun onDestroy() {
        GimbalBleManager.serviceRunning = false
        GimbalBleManager.stopMotion()
        GimbalBleManager.updateStatus(GimbalBleManager.statusText)
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        if (event?.eventType == AccessibilityEvent.TYPE_WINDOW_STATE_CHANGED) {
            event.packageName?.let { foregroundPkg = it.toString() }
        }
    }

    override fun onInterrupt() {
        GimbalBleManager.stopMotion()
    }

    /** true daca tasta vine de la un dispozitiv extern (telecomanda), nu de la butoanele telefonului */
    private fun isExternal(event: KeyEvent): Boolean {
        val dev = event.device ?: InputDevice.getDevice(event.deviceId) ?: return false
        if (Build.VERSION.SDK_INT >= 29) return dev.isExternal
        return !dev.isVirtual && !dev.name.contains("gpio", true) && !dev.name.contains("pon", true)
    }

    private fun isCameraOpen(): Boolean {
        val pkg = runCatching { rootInActiveWindow?.packageName?.toString() }.getOrNull() ?: foregroundPkg
        return pkg.contains("camera", ignoreCase = true)
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        val isDown = event.action == KeyEvent.ACTION_DOWN
        val isUp = event.action == KeyEvent.ACTION_UP
        val firstDown = isDown && event.repeatCount == 0
        val external = isExternal(event)

        // Jurnal pentru depanare
        if (firstDown || isUp) {
            val name = KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")
            val src = event.device?.name ?: if (external) "extern" else "telefon"
            val act = if (isDown) "▼" else "▲"
            GimbalBleManager.lastKeyDebug = "$name ($code)"
            GimbalBleManager.logKey("$act $name  ·  $src")
            GimbalBleManager.updateStatus(GimbalBleManager.statusText)
        } else if (isDown && event.repeatCount == 1) {
            GimbalBleManager.logKey("   ↻ $code se repetă (ținut apăsat)")
            GimbalBleManager.updateStatus(GimbalBleManager.statusText)
        }

        // Butoanele fizice ale telefonului nu sunt atinse niciodata
        if (!external) return false
        if (code == KeyEvent.KEYCODE_POWER) return false

        // ---------- CAMERA (merge si fara gimbal conectat) ----------
        when (code) {
            // Play-Pause = declansator (poza / start-stop filmare)
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY,
            KeyEvent.KEYCODE_MEDIA_PAUSE, KeyEvent.KEYCODE_HEADSETHOOK -> {
                if (!isCameraOpen()) return false   // in afara Camerei: play/pause normal
                if (firstDown) pressShutter()
                return true
            }
            // Volum + / - = zoom (scurt = putin, tinut = salt)
            KeyEvent.KEYCODE_VOLUME_UP, KeyEvent.KEYCODE_VOLUME_DOWN -> {
                if (!isCameraOpen()) return false   // in afara Camerei: volum normal
                val dir = if (code == KeyEvent.KEYCODE_VOLUME_UP) 1 else -1
                if (firstDown) {
                    handler.removeCallbacks(zoomHoldRunnable)
                    zoomHeldDir = dir
                    zoomHoldSteps = 0
                    handler.postDelayed(zoomHoldRunnable, 450)
                } else if (isUp) {
                    handler.removeCallbacks(zoomHoldRunnable)
                    if (zoomHeldDir == dir && zoomHoldSteps == 0) {
                        val r = GimbalBleManager.zoomTapRatio
                        pinch(if (dir > 0) r else 1f / r, 250)
                    }
                    zoomHeldDir = 0
                }
                return true
            }
        }

        // ---------- GIMBAL ----------
        if (!GimbalBleManager.isConnected) return false

        // Mapare K-207Z in modul MEDIA (testata):
        // stanga = PREVIOUS(88), dreapta = NEXT(87), sus = FAST_FORWARD(90), jos = REWIND(89)
        val move: Pair<Int, Int>? = when (code) {
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_A,
            KeyEvent.KEYCODE_MEDIA_PREVIOUS -> 0 to -1
            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_D,
            KeyEvent.KEYCODE_MEDIA_NEXT -> 0 to 1
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_W,
            KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> 1 to 1
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_S,
            KeyEvent.KEYCODE_MEDIA_REWIND -> 1 to -1
            else -> null
        }
        if (move != null) {
            val (axis, dir) = move
            if (isDown) GimbalBleManager.pressDir(axis, dir)
            else if (isUp) GimbalBleManager.releaseDir(axis, dir)
            return true
        }

        when (code) {
            // Butoane gamepad / OK -> mod lent / normal
            KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B,
            KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_Y,
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                if (firstDown) {
                    GimbalBleManager.slowMode = !GimbalBleManager.slowMode
                    GimbalBleManager.updateStatus(GimbalBleManager.statusText)
                }
                return true
            }
        }
        return false
    }

    // ================= Gesturi pe ecran =================

    private fun screenSize(): Pair<Float, Float> {
        return if (Build.VERSION.SDK_INT >= 30) {
            val b = getSystemService(WindowManager::class.java).currentWindowMetrics.bounds
            b.width().toFloat() to b.height().toFloat()
        } else {
            val dm = resources.displayMetrics
            dm.widthPixels.toFloat() to dm.heightPixels.toFloat()
        }
    }

    private fun tap(x: Float, y: Float) {
        val p = Path().apply { moveTo(x, y) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(p, 0, 60))
            .build()
        dispatchGesture(g, null, null)
    }

    /** ratio > 1 = zoom in, ratio < 1 = zoom out. Doua degete pe orizontala, in centrul imaginii. */
    private fun pinch(ratio: Float, durationMs: Long) {
        val (w, h) = screenSize()
        val cx = w / 2f
        val cy = h * 0.42f
        val maxHalf = w * 0.42f
        val startHalf: Float
        val endHalf: Float
        if (ratio >= 1f) {
            startHalf = (maxHalf / ratio).coerceAtLeast(w * 0.06f)
            endHalf = startHalf * ratio
        } else {
            startHalf = maxHalf
            endHalf = maxHalf * ratio
        }
        val left = Path().apply { moveTo(cx - startHalf, cy); lineTo(cx - endHalf, cy) }
        val right = Path().apply { moveTo(cx + startHalf, cy); lineTo(cx + endHalf, cy) }
        val g = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(left, 0, durationMs))
            .addStroke(GestureDescription.StrokeDescription(right, 0, durationMs))
            .build()
        dispatchGesture(g, null, null)
    }

    private val shutterDesc = Regex(
        "(shutter|take pic|take photo|capture|record|fotografi|captur|înregistr|inregistr|declanș|declans|filmare)",
        RegexOption.IGNORE_CASE
    )

    private fun findShutter(root: AccessibilityNodeInfo): AccessibilityNodeInfo? {
        // 1) dupa ID (ex: ...:id/shutter_button)
        var byDesc: AccessibilityNodeInfo? = null
        val stack = ArrayDeque<AccessibilityNodeInfo>()
        stack.addLast(root)
        var visited = 0
        while (stack.isNotEmpty() && visited < 600) {
            val n = stack.removeLast()
            visited++
            if (n.isVisibleToUser) {
                val id = n.viewIdResourceName ?: ""
                if (id.contains("shutter", true) && !id.contains("sound", true)) return n
                val desc = (n.contentDescription ?: "").toString()
                if (byDesc == null && n.isClickable && shutterDesc.containsMatchIn(desc)) byDesc = n
            }
            for (i in 0 until n.childCount) n.getChild(i)?.let { stack.addLast(it) }
        }
        // 2) dupa descriere
        return byDesc
    }

    private fun pressShutter() {
        val root = runCatching { rootInActiveWindow }.getOrNull()
        val node = root?.let { findShutter(it) }
        if (node != null) {
            val r = Rect()
            node.getBoundsInScreen(r)
            tap(r.exactCenterX(), r.exactCenterY())
            val what = node.viewIdResourceName?.substringAfter("/") ?: node.contentDescription ?: "?"
            GimbalBleManager.logKey("   📷 declanșator găsit: $what")
        } else {
            val (w, h) = screenSize()
            tap(w / 2f, h * GimbalBleManager.shutterYPct / 100f)
            GimbalBleManager.logKey("   📷 apăsat la ${GimbalBleManager.shutterYPct}% (negăsit automat)")
        }
        GimbalBleManager.updateStatus(GimbalBleManager.statusText)
    }
}
