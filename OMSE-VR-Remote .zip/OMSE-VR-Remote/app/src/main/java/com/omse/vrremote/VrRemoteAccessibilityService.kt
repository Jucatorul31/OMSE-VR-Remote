package com.omse.vrremote

import android.accessibilityservice.AccessibilityService
import android.view.InputDevice
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class VrRemoteAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        GimbalBleManager.serviceRunning = true
        GimbalBleManager.updateStatus(GimbalBleManager.statusText)
    }

    override fun onDestroy() {
        GimbalBleManager.serviceRunning = false
        GimbalBleManager.stopMotion()
        GimbalBleManager.updateStatus(GimbalBleManager.statusText)
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {
        GimbalBleManager.stopMotion()
    }

    /** true daca tasta vine de la un dispozitiv extern (telecomanda), nu de la butoanele telefonului */
    private fun isExternal(event: KeyEvent): Boolean {
        val dev = event.device ?: InputDevice.getDevice(event.deviceId) ?: return false
        return dev.isExternal
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        val isDown = event.action == KeyEvent.ACTION_DOWN
        val isUp = event.action == KeyEvent.ACTION_UP
        val firstDown = isDown && event.repeatCount == 0
        val external = isExternal(event)

        // Jurnal pentru depanare: tasta, apasat/eliberat, repetari, sursa
        if (firstDown || isUp) {
            val name = KeyEvent.keyCodeToString(code).removePrefix("KEYCODE_")
            val src = event.device?.name ?: if (external) "extern" else "telefon"
            val act = if (isDown) "▼" else "▲"
            GimbalBleManager.lastKeyDebug = "$name ($code)"
            GimbalBleManager.logKey("$act $name  ·  $src")
            GimbalBleManager.updateStatus(GimbalBleManager.statusText)
        } else if (isDown && event.repeatCount == 1) {
            GimbalBleManager.logKey("   ↻ $code se repetă (ținut apăsat)")
            GimbalBleManager.updateStatus(GimbalBleManager.statusText)
        }

        // Butoanele fizice ale telefonului (volum, power) nu sunt atinse niciodata
        if (!external) return false
        if (code == KeyEvent.KEYCODE_POWER) return false

        // Daca gimbalul nu e conectat, nu blocam nimic
        if (!GimbalBleManager.isConnected) return false

        val move: Pair<Int, Int>? = when (code) {
            // Stanga
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_A,
            KeyEvent.KEYCODE_MEDIA_PREVIOUS, KeyEvent.KEYCODE_MEDIA_REWIND -> 0 to -1
            // Dreapta
            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_D,
            KeyEvent.KEYCODE_MEDIA_NEXT, KeyEvent.KEYCODE_MEDIA_FAST_FORWARD -> 0 to 1
            // Sus
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_W,
            KeyEvent.KEYCODE_VOLUME_UP -> 1 to 1
            // Jos
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_S,
            KeyEvent.KEYCODE_VOLUME_DOWN -> 1 to -1
            else -> null
        }

        if (move != null) {
            val (axis, dir) = move
            if (isDown) GimbalBleManager.pressDir(axis, dir)
            else if (isUp) GimbalBleManager.releaseDir(axis, dir)
            return true
        }

        when (code) {
            // Trigger / Play-Pause / OK / butoane gamepad -> comutare mod lent / normal
            KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE, KeyEvent.KEYCODE_MEDIA_PLAY,
            KeyEvent.KEYCODE_MEDIA_PAUSE, KeyEvent.KEYCODE_HEADSETHOOK,
            KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_B,
            KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_Y,
            KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                if (firstDown) {
                    GimbalBleManager.slowMode = !GimbalBleManager.slowMode
                    GimbalBleManager.updateStatus(GimbalBleManager.statusText)
                }
                return true
            }
        }
        return false
    }
}
