package com.omse.vrremote

import android.annotation.SuppressLint
import android.bluetooth.*
import android.bluetooth.le.ScanCallback
import android.bluetooth.le.ScanResult
import android.bluetooth.le.ScanSettings
import android.content.Context
import android.os.Build
import android.os.Handler
import android.os.Looper
import java.util.UUID

@SuppressLint("MissingPermission")
object GimbalBleManager {

    private val SERVICE_UUID = UUID.fromString("0000fff0-0000-1000-8000-00805f9b34fb")
    private val CHAR_NOTIFY_UUID = UUID.fromString("0000fff4-0000-1000-8000-00805f9b34fb")
    private val CHAR_WRITE_UUID = UUID.fromString("0000fff5-0000-1000-8000-00805f9b34fb")
    private val CCCD_UUID = UUID.fromString("00002902-0000-1000-8000-00805f9b34fb")

    private const val SPEED_FLAG: Byte = 0x80.toByte()
    private const val LOOP_MS = 40L // 25 Hz

    private var gatt: BluetoothGatt? = null
    private var writeChar: BluetoothGattCharacteristic? = null
    private var seqNum = 1

    // Stare control (actualizata de AccessibilityService)
    @Volatile var dirX: Int = 0       // -1 stanga, 0 stop, 1 dreapta
    @Volatile var dirY: Int = 0       // -1 jos, 0 stop, 1 sus
    @Volatile var maxSpeedDeg: Int = 55
    @Volatile var slowMode: Boolean = false
    @Volatile var invertYaw: Boolean = false
    @Volatile var invertPitch: Boolean = false
    @Volatile var isConnected: Boolean = false
    @Volatile var statusText: String = "Deconectat"
    @Volatile var lastKeyDebug: String = "-"
    @Volatile var serviceRunning: Boolean = false

    var onStatusChanged: (() -> Unit)? = null

    private val handler = Handler(Looper.getMainLooper())
    private var wasMoving = false
    private var activeScanCallback: ScanCallback? = null

    // Bucla de 25Hz care trimite viteza cat timp tii joystick-ul intr-o directie
    private val controlLoop = object : Runnable {
        override fun run() {
            if (isConnected && writeChar != null) {
                val mult = if (slowMode) 0.35f else 1.0f
                val spd = (maxSpeedDeg * 10 * mult).toInt()

                var yaw = dirX * spd
                var pitch = dirY * spd
                if (invertYaw) yaw = -yaw
                if (invertPitch) pitch = -pitch

                if (yaw != 0 || pitch != 0) {
                    sendSpeed(pitch, yaw)
                    wasMoving = true
                } else if (wasMoving) {
                    // la eliberare: trimitem stop de 2 ori (pachetele NO_RESPONSE se pot pierde)
                    sendSpeed(0, 0)
                    handler.postDelayed({ if (dirX == 0 && dirY == 0) sendSpeed(0, 0) }, 15)
                    wasMoving = false
                }
            }
            handler.postDelayed(this, LOOP_MS)
        }
    }

    init {
        handler.post(controlLoop)
    }

    fun stopMotion() {
        dirX = 0
        dirY = 0
    }

    fun startScanAndConnect(context: Context) {
        val appCtx = context.applicationContext
        val btManager = appCtx.getSystemService(Context.BLUETOOTH_SERVICE) as BluetoothManager
        val adapter = btManager.adapter ?: run {
            updateStatus("Bluetooth indisponibil")
            return
        }
        if (!adapter.isEnabled) {
            updateStatus("Pornește Bluetooth-ul!")
            return
        }
        val scanner = adapter.bluetoothLeScanner ?: run {
            updateStatus("Pornește Bluetooth-ul!")
            return
        }

        // Opreste o scanare anterioara, daca exista
        activeScanCallback?.let { runCatching { scanner.stopScan(it) } }

        updateStatus("Scanez după OMSE...")
        val scanCallback = object : ScanCallback() {
            override fun onScanResult(callbackType: Int, result: ScanResult) {
                val name = result.scanRecord?.deviceName ?: result.device.name ?: return
                if (name.startsWith("OM", ignoreCase = true)) {
                    runCatching { scanner.stopScan(this) }
                    activeScanCallback = null
                    updateStatus("Găsit $name, conectez...")
                    connectDevice(appCtx, result.device, name)
                }
            }

            override fun onScanFailed(errorCode: Int) {
                activeScanCallback = null
                updateStatus("Scanare eșuată (cod $errorCode)")
            }
        }
        activeScanCallback = scanCallback
        val settings = ScanSettings.Builder()
            .setScanMode(ScanSettings.SCAN_MODE_LOW_LATENCY)
            .build()
        try {
            scanner.startScan(null, settings, scanCallback)
        } catch (e: SecurityException) {
            activeScanCallback = null
            updateStatus("Lipsește permisiunea Bluetooth")
            return
        }

        // Opreste scanarea dupa 10 secunde daca nu gaseste gimbalul
        handler.postDelayed({
            if (activeScanCallback === scanCallback) {
                runCatching { scanner.stopScan(scanCallback) }
                activeScanCallback = null
                if (!isConnected) updateStatus("Nu am găsit gimbalul (e pornit?)")
            }
        }, 10000)
    }

    private fun connectDevice(context: Context, device: BluetoothDevice, name: String) {
        gatt?.close()
        gatt = device.connectGatt(context, false, object : BluetoothGattCallback() {
            override fun onConnectionStateChange(g: BluetoothGatt, status: Int, newState: Int) {
                if (newState == BluetoothProfile.STATE_CONNECTED) {
                    // conexiune rapida = latenta mai mica intre pachete
                    g.requestConnectionPriority(BluetoothGatt.CONNECTION_PRIORITY_HIGH)
                    g.discoverServices()
                } else if (newState == BluetoothProfile.STATE_DISCONNECTED) {
                    isConnected = false
                    writeChar = null
                    stopMotion()
                    updateStatus("Deconectat")
                }
            }

            override fun onServicesDiscovered(g: BluetoothGatt, status: Int) {
                val service = g.getService(SERVICE_UUID) ?: run {
                    updateStatus("Serviciul fff0 lipsește")
                    return
                }
                writeChar = service.getCharacteristic(CHAR_WRITE_UUID)
                val notifyChar = service.getCharacteristic(CHAR_NOTIFY_UUID)

                if (notifyChar != null) {
                    g.setCharacteristicNotification(notifyChar, true)
                    val desc = notifyChar.getDescriptor(CCCD_UUID)
                    if (desc != null) {
                        val v = BluetoothGattDescriptor.ENABLE_NOTIFICATION_VALUE
                        if (Build.VERSION.SDK_INT >= 33) {
                            g.writeDescriptor(desc, v)
                        } else {
                            @Suppress("DEPRECATION")
                            desc.value = v
                            @Suppress("DEPRECATION")
                            g.writeDescriptor(desc)
                        }
                    }
                }
                isConnected = (writeChar != null)
                updateStatus(if (isConnected) "Conectat: $name" else "Eroare fff5")
            }
        }, BluetoothDevice.TRANSPORT_LE)
    }

    fun disconnect() {
        stopMotion()
        if (isConnected) sendSpeed(0, 0)
        gatt?.disconnect()
        gatt?.close()
        gatt = null
        writeChar = null
        isConnected = false
        updateStatus("Deconectat")
    }

    // --- Protocol DJI DUML ---
    private fun crc8(data: ByteArray, len: Int): Int {
        var crc = 0x77
        for (i in 0 until len) {
            crc = crc xor (data[i].toInt() and 0xFF)
            repeat(8) {
                crc = if ((crc and 1) != 0) (crc ushr 1) xor 0x8C else (crc ushr 1)
            }
        }
        return crc and 0xFF
    }

    private fun crc16(data: ByteArray, len: Int): Int {
        var crc = 0x3692
        for (i in 0 until len) {
            crc = crc xor (data[i].toInt() and 0xFF)
            repeat(8) {
                crc = if ((crc and 1) != 0) (crc ushr 1) xor 0x8408 else (crc ushr 1)
            }
        }
        return crc and 0xFFFF
    }

    @Synchronized
    private fun sendDuml(cmdSet: Int, cmdId: Int, payload: ByteArray) {
        val g = gatt ?: return
        val ch = writeChar ?: return
        val totalLen = 11 + payload.size + 2
        val buf = ByteArray(totalLen)

        buf[0] = 0x55
        buf[1] = (totalLen and 0xFF).toByte()
        buf[2] = (((totalLen ushr 8) and 0x03) or 0x04).toByte()
        buf[3] = crc8(buf, 3).toByte()
        buf[4] = 0x02 // App
        buf[5] = 0x04 // Gimbal
        buf[6] = (seqNum and 0xFF).toByte()
        buf[7] = ((seqNum ushr 8) and 0xFF).toByte()
        seqNum = (seqNum + 1) and 0xFFFF
        buf[8] = 0x40
        buf[9] = cmdSet.toByte()
        buf[10] = cmdId.toByte()
        System.arraycopy(payload, 0, buf, 11, payload.size)

        val c16 = crc16(buf, totalLen - 2)
        buf[totalLen - 2] = (c16 and 0xFF).toByte()
        buf[totalLen - 1] = ((c16 ushr 8) and 0xFF).toByte()

        val type = BluetoothGattCharacteristic.WRITE_TYPE_NO_RESPONSE
        try {
            if (Build.VERSION.SDK_INT >= 33) {
                g.writeCharacteristic(ch, buf, type)
            } else {
                @Suppress("DEPRECATION")
                ch.writeType = type
                @Suppress("DEPRECATION")
                ch.value = buf
                @Suppress("DEPRECATION")
                g.writeCharacteristic(ch)
            }
        } catch (_: SecurityException) {
            updateStatus("Lipsește permisiunea Bluetooth")
        }
    }

    fun sendSpeed(pitch: Int, yaw: Int) {
        // Ordinea validata pe OMSE: Yaw (bytes 0..1), Roll=0 (2..3), Pitch (4..5), Flag (6)
        val payload = byteArrayOf(
            (yaw and 0xFF).toByte(), ((yaw ushr 8) and 0xFF).toByte(),
            0, 0,
            (pitch and 0xFF).toByte(), ((pitch ushr 8) and 0xFF).toByte(),
            SPEED_FLAG
        )
        sendDuml(0x04, 0x0C, payload)
    }

    fun sendRecenter() {
        sendDuml(0x04, 0x4C, byteArrayOf(0x01, 0x00))
    }

    fun updateStatus(msg: String) {
        statusText = msg
        handler.post { onStatusChanged?.invoke() }
    }
}
