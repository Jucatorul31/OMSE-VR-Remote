package com.omse.vrremote

import android.accessibilityservice.AccessibilityService
import android.view.KeyEvent
import android.view.accessibility.AccessibilityEvent

class VrRemoteAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() {
        super.onServiceConnected()
        GimbalBleManager.serviceRunning = true
        GimbalBleManager.updateStatus(GimbalBleManager.statusText)
    }

    override fun onDestroy() {
        GimbalBleManager.serviceRunning = false
        GimbalBleManager.stopMotion()
        GimbalBleManager.updateStatus(GimbalBleManager.statusText)
        super.onDestroy()
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {
        // Nu avem nevoie de evenimente UI, doar de taste
    }

    override fun onInterrupt() {
        GimbalBleManager.stopMotion()
    }

    override fun onKeyEvent(event: KeyEvent): Boolean {
        val code = event.keyCode
        val isDown = event.action == KeyEvent.ACTION_DOWN
        val isUp = event.action == KeyEvent.ACTION_UP
        val firstDown = isDown && event.repeatCount == 0

        // Afisam in aplicatie ce tasta a trimis telecomanda (util pentru mapare)
        if (firstDown) {
            GimbalBleManager.lastKeyDebug = "${KeyEvent.keyCodeToString(code)} ($code)"
            GimbalBleManager.updateStatus(GimbalBleManager.statusText)
        }

        // Nu blocam niciodata tastele de volum/power ale telefonului
        if (code == KeyEvent.KEYCODE_VOLUME_UP || code == KeyEvent.KEYCODE_VOLUME_DOWN ||
            code == KeyEvent.KEYCODE_POWER) return false

        // Daca gimbalul nu e conectat, nu blocam tastele telefonului
        if (!GimbalBleManager.isConnected) return false

        when (code) {
            // Directii joystick (D-Pad sau WASD)
            KeyEvent.KEYCODE_DPAD_LEFT, KeyEvent.KEYCODE_A -> {
                if (isDown) GimbalBleManager.dirX = -1
                else if (isUp && GimbalBleManager.dirX == -1) GimbalBleManager.dirX = 0
                return true
            }
            KeyEvent.KEYCODE_DPAD_RIGHT, KeyEvent.KEYCODE_D -> {
                if (isDown) GimbalBleManager.dirX = 1
                else if (isUp && GimbalBleManager.dirX == 1) GimbalBleManager.dirX = 0
                return true
            }
            KeyEvent.KEYCODE_DPAD_UP, KeyEvent.KEYCODE_W -> {
                if (isDown) GimbalBleManager.dirY = 1
                else if (isUp && GimbalBleManager.dirY == 1) GimbalBleManager.dirY = 0
                return true
            }
            KeyEvent.KEYCODE_DPAD_DOWN, KeyEvent.KEYCODE_S -> {
                if (isDown) GimbalBleManager.dirY = -1
                else if (isUp && GimbalBleManager.dirY == -1) GimbalBleManager.dirY = 0
                return true
            }

            // Recenter (buton A / OK / Enter)
            KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_DPAD_CENTER, KeyEvent.KEYCODE_ENTER -> {
                if (firstDown) GimbalBleManager.sendRecenter()
                return true
            }

            // Comutare viteza Lenta / Normala (buton B / X / Y)
            KeyEvent.KEYCODE_BUTTON_B, KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_Y -> {
                if (firstDown) {
                    GimbalBleManager.slowMode = !GimbalBleManager.slowMode
                    GimbalBleManager.updateStatus(GimbalBleManager.statusText)
                }
                return true
            }
        }
        return false
    }
}
