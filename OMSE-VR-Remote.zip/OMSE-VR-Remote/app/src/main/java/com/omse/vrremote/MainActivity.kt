package com.omse.vrremote

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.widget.*

class MainActivity : Activity() {

    private lateinit var tvStatus: TextView
    private lateinit var tvService: TextView
    private lateinit var tvDebug: TextView
    private lateinit var tvSpeed: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

        // Cerere permisiuni Bluetooth la pornire
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
            requestPermissions(
                arrayOf(Manifest.permission.BLUETOOTH_SCAN, Manifest.permission.BLUETOOTH_CONNECT),
                101
            )
        } else {
            requestPermissions(arrayOf(Manifest.permission.ACCESS_FINE_LOCATION), 101)
        }

        // UI programatic Dark Mode (negru pur + cyan)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(Color.BLACK)
            setPadding(48, 80, 48, 48)
            gravity = Gravity.CENTER_HORIZONTAL
        }

        val title = TextView(this).apply {
            text = "OMSE VR BACKGROUND REMOTE"
            textSize = 20f
            setTextColor(Color.parseColor("#00E5FF"))
            setPadding(0, 0, 0, 32)
        }

        tvStatus = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            setPadding(0, 0, 0, 8)
        }

        tvService = TextView(this).apply {
            textSize = 14f
            setPadding(0, 0, 0, 16)
        }

        tvDebug = TextView(this).apply {
            textSize = 14f
            setTextColor(Color.parseColor("#8AA4B0"))
            setPadding(0, 0, 0, 32)
        }

        val btnConnect = Button(this).apply {
            text = "1. Conectează DJI OMSE"
            setOnClickListener { GimbalBleManager.startScanAndConnect(this@MainActivity) }
        }

        val btnAccess = Button(this).apply {
            text = "2. Activează Serviciul în Fundal"
            setOnClickListener {
                startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
            }
        }

        val btnRecenter = Button(this).apply {
            text = "Recenter Gimbal"
            setOnClickListener { GimbalBleManager.sendRecenter() }
        }

        val btnDisconnect = Button(this).apply {
            text = "Deconectează"
            setOnClickListener { GimbalBleManager.disconnect() }
        }

        tvSpeed = TextView(this).apply {
            text = "Viteză maximă: ${GimbalBleManager.maxSpeedDeg}°/s"
            setTextColor(Color.parseColor("#00E5FF"))
            setPadding(0, 32, 0, 8)
        }

        val seekSpeed = SeekBar(this).apply {
            max = 110
            progress = GimbalBleManager.maxSpeedDeg - 10
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, p: Int, fromUser: Boolean) {
                    val v = p + 10
                    GimbalBleManager.maxSpeedDeg = v
                    tvSpeed.text = "Viteză maximă: $v°/s"
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }

        val cbInvYaw = CheckBox(this).apply {
            text = "Inversează Stânga / Dreapta"
            setTextColor(Color.WHITE)
            isChecked = GimbalBleManager.invertYaw
            setOnCheckedChangeListener { _, isChecked -> GimbalBleManager.invertYaw = isChecked }
        }

        val cbInvPitch = CheckBox(this).apply {
            text = "Inversează Sus / Jos"
            setTextColor(Color.WHITE)
            isChecked = GimbalBleManager.invertPitch
            setOnCheckedChangeListener { _, isChecked -> GimbalBleManager.invertPitch = isChecked }
        }

        val tvHelp = TextView(this).apply {
            text = "Joystick = mișcă gimbalul · A / OK = Recenter · B / X / Y = mod lent\n" +
                    "După conectare, deschide aplicația Camera — telecomanda merge în fundal."
            textSize = 12f
            setTextColor(Color.parseColor("#8AA4B0"))
            setPadding(0, 32, 0, 0)
        }

        root.addView(title)
        root.addView(tvStatus)
        root.addView(tvService)
        root.addView(tvDebug)
        root.addView(btnConnect)
        root.addView(btnAccess)
        root.addView(btnRecenter)
        root.addView(btnDisconnect)
        root.addView(tvSpeed)
        root.addView(seekSpeed)
        root.addView(cbInvYaw)
        root.addView(cbInvPitch)
        root.addView(tvHelp)

        setContentView(ScrollView(this).apply {
            setBackgroundColor(Color.BLACK)
            addView(root)
        })

        GimbalBleManager.onStatusChanged = { refreshUi() }
        refreshUi()
    }

    override fun onResume() {
        super.onResume()
        refreshUi()
    }

    override fun onDestroy() {
        GimbalBleManager.onStatusChanged = null
        super.onDestroy()
    }

    private fun refreshUi() {
        val mod = if (GimbalBleManager.slowMode) "Lent (35%)" else "Normal"
        tvStatus.text = "Status: ${GimbalBleManager.statusText} | Mod: $mod"
        if (GimbalBleManager.serviceRunning) {
            tvService.text = "Serviciu fundal: ACTIV"
            tvService.setTextColor(Color.parseColor("#00E676"))
        } else {
            tvService.text = "Serviciu fundal: OPRIT (apasă butonul 2)"
            tvService.setTextColor(Color.parseColor("#FF5252"))
        }
        tvDebug.text = "Ultima tastă VR: ${GimbalBleManager.lastKeyDebug}"
    }
}
