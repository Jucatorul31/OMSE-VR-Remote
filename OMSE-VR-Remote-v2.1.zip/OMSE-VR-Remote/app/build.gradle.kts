plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.omse.vrremote"
    compileSdk = 35

    defaultConfig {
        applicationId = "com.omse.vrremote"
        minSdk = 26
        targetSdk = 35
        versionCode = 3
        versionName = "2.1"
        // Numele fisierului APK final: OMSE-VR-Remote-v2.1.apk
        setProperty("archivesBaseName", "OMSE-VR-Remote-v$versionName")
    }

    // Cheie fixa: versiunile viitoare se instaleaza peste cea veche fara dezinstalare
    signingConfigs {
        create("fixed") {
            storeFile = file("omse-release.jks")
            storePassword = "omse1234"
            keyAlias = "omse"
            keyPassword = "omse1234"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
